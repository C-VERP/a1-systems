# -*- coding: utf-8 -*-
#################################################################################
# Author      : Webkul Software Pvt. Ltd. (<https://webkul.com/>)
# Copyright(c): 2015-Present Webkul Software Pvt. Ltd.
# All Rights Reserved.
#
#
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#
# You should have received a copy of the License along with this program.
# If not, see <https://store.webkul.com/license.html/>
#################################################################################
{
  "name"                 :  "Website Auction",
  "summary"              :  """Odoo Website Auction is a robust solution that empowers businesses to seamlessly host and manage auctions directly on their Odoo website. With advanced features like auto-bidding, real-time notifications, and customizable auction rules, it enhances user engagement and simplifies the auction management process. Whether you’re selling products or services, Odoo Website Auction helps you reach a wider audience while providing a smooth and interactive bidding experience.""",
  "category"             :  "Website",
  "version"              :  "1.1.0",
  "sequence"             :  1,
  "author"               :  "Webkul Software Pvt. Ltd.",
  "license"              :  "Other proprietary",
 
  "website"              :  "https://store.webkul.com/Odoo-Website-Auction.html",
  "description"          :  """ Transform your Odoo website into a high-performing auction platform with Odoo Website Auction. This feature-rich module supports both simple and auto-bidding, ensuring flexibility for all users. Real-time notifications keep participants informed, while admins can effortlessly configure auction rules, track bids, and monitor participants. With comprehensive control over every aspect of your auctions, this module makes it easy to elevate your eCommerce strategy and attract competitive bidders from across the globe. It's the perfect tool for businesses seeking to boost sales through exciting online auctions.

                            """,
  "live_test_url"        :  "http://odoodemo.webkul.com/?module=website_auction&version=14.0&custom_url=/shop",
  "depends"              :  [
                             'website_sale',
                             'sale_stock',
                             'website_mail',
                             'website_virtual_product',
                             'website_webkul_addons',
                            ],
  "data"                 :  [
                             'edi/wk_auction_bidder.xml',
                             'edi/wk_auction_subscriber.xml',
                             'edi/wk_auction_admin.xml',
                             'data/cron.xml',
                             'data/data.xml',
                             'views/website_auction.xml',
                             'views/product_template.xml',
                             'views/my_account_template.xml',
                             'views/inherited_virtual_product.xml',
                             'views/auction_res_config.xml',
                             'views/webkul_addons_config_inherit_view.xml',
                             'views/auction_product_bids_template.xml',
                             'views/products_on_auction_views.xml',
                             'security/ir.model.access.csv',
                            ],
  "demo"                 :  ['demo/demo.xml'],
  "assets"               :  {
                              'web.assets_frontend':  [
                                'website_auction/static/src/css/website_auction.css',
                                'website_auction/static/src/css/auction.scss',
                                'website_auction/static/src/js/jquery.downCount.js',
                                'website_auction/static/src/js/wk_website_countdown.js',
                                'website_auction/static/src/js/website_auction.js',
                                'website_auction/static/src/js/listener.js'
                              ],
                            },
  "images"               :  ['static/description/Banner.png'],
  "application"          :  True,
  "installable"          :  True,
  "price"                :  149,
  "currency"             :  "USD",
}
