# -*- coding: utf-8 -*-
#################################################################################
#
#   Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#   See LICENSE file for full copyright and licensing details.
#################################################################################
import werkzeug
from odoo import fields, http, SUPERUSER_ID, tools, _
from odoo.http import request
from werkzeug.exceptions import Forbidden, NotFound
from odoo.addons.website_sale.controllers.main import WebsiteSale as  website_sale
from odoo.addons.website_sale.controllers.main import WebsiteSale, TableCompute
from odoo.addons.website_virtual_product.controllers.main import website_virtual_product
from odoo.addons.website_auction.models.website_auction_exception import *
from odoo.tools import lazy, groupby
from odoo.addons.website.controllers.main import QueryURL
# from odoo.addons.http_routing.models.ir_http import slug
from odoo.exceptions import UserError
from odoo.addons.portal.controllers.portal import CustomerPortal, pager as portal_pager
from odoo.addons.payment.controllers import portal as payment_portal
import datetime
import logging

_logger = logging.getLogger(__name__)


class CustomerPortalInherit(CustomerPortal):

    
    def _prepare_home_portal_values(self, counters):
        values = super(CustomerPortalInherit, self)._prepare_home_portal_values(counters)
        website = request.env['website'].get_current_website()
        if 'win_auction_count' in counters:
            Auction = request.env['wk.website.auction']
            domain = [
            ('state','in',['complete','finish']),
            # ('winner_id', '=', partner_id)
            ]
            auctions = Auction.search(domain)
            partner_id = request.website._get_website_partner().id
            auctions = auctions.filtered(lambda auction:auction.winner_id.id==partner_id)
            values['win_auction_count'] = len(auctions)
        return values

    def _prepare_portal_layout_values(self):
        values = super(CustomerPortalInherit, self)._prepare_portal_layout_values()
        partner = request.env.user.partner_id
        partner_id = request.website._get_website_partner().id
        Auction = request.env['wk.website.auction']
        domain = [
            ('state','in',['complete','finish']),
            # ('winner_id', '=', partner_id)
        ]
        auctions = Auction.search(domain)
        auctions = auctions.filtered(lambda auction:auction.winner_id.id==partner_id)
        values.update({
            'win_auction_count': len(auctions),
        })
        return values

    @http.route(
        [
        '/my/auctions',
        '/my/auctions/page/<int:page>',
        ],
         type='http', auth="user", website=True)
    def portal_my_auctions(self, page=1, **kw):
        values = self._prepare_portal_layout_values()
        partner_id = request.website._get_website_partner().id

        Auction = request.env['wk.website.auction']
        domain = [
            ('state','in',['complete','finish']),
            # ('winner_id', '=', partner_id)
        ]
        auction_count = Auction.search_count(domain)
        pager = request.website.pager(
            url='/my/auctions',
            total=auction_count,
            page=page,
            step=5
        )
        auctions = Auction.search(domain, limit=5, offset=pager['offset'],order='id desc')
        auctions = auctions.filtered(lambda auction:auction.winner_id.id==partner_id)

        if not len(auctions):
            values['no_auctions']=1
        values['won_auctions'] = auctions
        values['pager'] = pager
        values['page_name'] = 'auctions'
        values['default_url'] ='/my/auctions'
        return  request.render("website_auction.my_auction", values)
    
    @http.route(
        [
            '/my/bids',
            '/my/bids/page/<int:page>',
        ],
         type='http', auth="user", website=True)
    def portal_my_bids(self, page=1, state=None,**kwargs):
        partner_id = request.website._get_website_partner().id
        values = self._prepare_portal_layout_values()
        Bidder = request.env['wk.auction.bidder'].sudo()
        domain = [('partner_id','=',partner_id)]
        if state=='active':
            domain+= [('state', '=', 'active')]
        else:
            domain+= [('state', '!=', 'active')]
        bid_count = Bidder.search_count(domain)
        pager = request.website.pager(
            url='/my/bids',
            total=bid_count,
            page=page,
            url_args={'state': state},

            step=5
        )
        bids = Bidder.search(domain, limit=5, offset=pager['offset'],order='id desc')
        if state=='active' :
            values['no_active_bids']=not len(bids)
            values['active_bids'] = bids
        else:
            values['no_bids']=not len(bids)
            values['all_bids'] = bids
        values['pager'] = pager
        values['page_name'] = 'auctions'
        return  request.render("website_auction.my_auction", values)

class WebsiteSale(website_sale):
    
    def _auction_get_query_url_kwargs(self, search, order=None, tags=None, **post):
        return {
            'search': search,
            'tags': tags,
            'order': order,
        }
    
    def _auction_lookup_products(self, options, post, search, website):
        sort_mapping = ['name desc','name asc','current_price asc','current_price desc']
        product_count, details, fuzzy_search_term = website._search_with_fuzzy("products_only", search,
                                                                               limit=None,
                                                                               order=False,
                                                                               options=options)
        search_result = details[0].get('results', request.env['wk.website.auction']).with_context(bin_size=True)
        price_order_data = {}
        name_order_data = {}
        for product_id in search_result:
            name_order_data[product_id.id] = product_id.tmpl_auction_ids[0].name
            price_order_data[product_id.id] = product_id.tmpl_auction_ids[0].current_price

        order = self._get_search_order(post)
        order_list = order.split(', ')
        filter_order = list(filter(lambda data: data in sort_mapping,order_list))
        sort_order_data = {}
        if filter_order:
            if filter_order[0] == 'current_price asc':
                sort_order_data = dict(sorted(price_order_data.items(), key=lambda item: item[1]))
            elif filter_order[0] == 'current_price desc':
                sort_order_data = dict(sorted(price_order_data.items(), key=lambda item: item[1],reverse = True))
            elif filter_order[0] == 'name asc':
                sort_order_data = dict(sorted(name_order_data.items(), key=lambda item: item[1]))
            elif filter_order[0] == 'name desc':
                sort_order_data = dict(sorted(name_order_data.items(), key=lambda item: item[1],reverse = True))

        if sort_order_data:
            sort_product_ids = sort_order_data.keys()
            search_result = request.env['product.template'].browse(sort_product_ids)
        return fuzzy_search_term, product_count, search_result
    
    @http.route(['/products-on-auction',
                 '/products-on-auction/page/<int:page>',
                 ],
        type='http', auth="public", website=True)
    def product_on_auction(self, page=0, search='', ppg=False, **post):
        add_qty = int(post.get('add_qty', 1))
        website = request.env['website'].get_current_website()
        website_domain = website.website_domain()
        if ppg:
            try:
                ppg = int(ppg)
                post['ppg'] = ppg
            except ValueError:
                ppg = False
        if not ppg:
            ppg = website.shop_ppg or 20

        ppr = website.shop_ppr or 4
        gap = website.shop_gap or "16px"
        
        keep = QueryURL('/products-on-auction', **self._auction_get_query_url_kwargs(search, **post))

        now = datetime.datetime.timestamp(datetime.datetime.now())
        pricelist = website.pricelist_id
        if 'website_sale_pricelist_time' in request.session:
            pricelist_save_time = request.session['website_sale_pricelist_time']
            if pricelist_save_time < now - 60*60:
                request.session.pop('website_sale_current_pl', None)
                website.invalidate_recordset(['pricelist_id'])
                pricelist = website.pricelist_id
                request.session['website_sale_pricelist_time'] = now
                request.session['website_sale_current_pl'] = pricelist.id
        else:
            request.session['website_sale_pricelist_time'] = now
            request.session['website_sale_current_pl'] = pricelist.id

        filter_by_price_enabled = website.is_view_active('website_sale.filter_products_price')
        if filter_by_price_enabled:
            company_currency = website.company_id.currency_id
            conversion_rate = request.env['res.currency']._get_conversion_rate(
                company_currency, website.currency_id, request.website.company_id, fields.Date.today())
        else:
            conversion_rate = 1

        url = "/products-on-auction"
        if search:
            post["search"] = search
            post["auction"] = 'all' if not post.get('auction') else post.get('auction')

        options = self._get_search_options(
            pricelist=pricelist,
            conversion_rate=conversion_rate,
            **post
        )

        live = False
        website.sudo().auction_default_sort = "all"
        if post.get("auction"):
            live =  post.get("auction") == "live"
            if post.get("auction") == 'all':
                website.sudo().auction_default_sort = "all"
            elif live:
                website.sudo().auction_default_sort = "live"
            elif post.get("auction") == 'complete':
                website.sudo().auction_default_sort = "complete"
            else:
                website.sudo().auction_default_sort = "upcoming"

        request.env['wk.website.auction'].product_default_sort = 'name asc'
        
        if post.get("order"):
            if post.get("order") == 'name asc':
                request.env['wk.website.auction'].product_default_sort = "name asc"
            elif post.get("order") == 'name desc':
                request.env['wk.website.auction'].product_default_sort = "name desc"
            elif post.get("order") == 'current_price asc':
                request.env['wk.website.auction'].product_default_sort = "current_price asc"
            else:
                request.env['wk.website.auction'].product_default_sort = "current_price dsc"
                
        request.update_context(**{"auction":True,"live":live,"auction_default_sort":post.get("auction")})
        fuzzy_search_term, product_count, search_product = self._auction_lookup_products(options, post, search, website)
        pager = website.pager(url=url, total=product_count, page=page, step=ppg, scope=7, url_args=post)
        offset = pager['offset']
        products = search_product[offset:offset + ppg]

        layout_mode = request.session.get('website_sale_shop_layout_mode')
        if not layout_mode:
            if website.viewref('website_sale.products_list_view').active:
                layout_mode = 'list'
            else:
                layout_mode = 'grid'
            request.session['website_sale_shop_layout_mode'] = layout_mode

        products_prices = lazy(lambda: products._get_sales_prices(pricelist))
        fiscal_position_sudo = website.fiscal_position_id.sudo()
        products_prices = lazy(lambda: products._get_sales_prices(pricelist, fiscal_position_sudo))
        values = {
            'search': fuzzy_search_term or search,
            'original_search': fuzzy_search_term and search,
            'order': post.get('order', ''),
            'pager': pager,
            'pricelist': pricelist,
            'fiscal_position': fiscal_position_sudo,
            'add_qty': add_qty,
            'products': products,
            'search_product': search_product,
            'search_count': product_count,  # common for all searchbox
            'bins': lazy(lambda: TableCompute().process(products, ppg, ppr)),
            'ppg': ppg,
            'ppr': ppr,
            'gap':gap,
            'keep': keep,
            'selected_attributes_hash': '',
            'layout_mode': layout_mode,
            'products_prices': products_prices,
            'get_product_prices': lambda product: lazy(lambda: products_prices[product.id]),
            'float_round': tools.float_round, 
        }
        values.update(self._get_additional_shop_values(values))
        return request.render("website_auction.product_on_auction", values)


    @http.route(['/shop/confirm_order'], type='http', auth="public", website=True,csrf=False)
    def shop_confirm_order(self, **post):
        order_sudo = request.website.sale_get_order()

        if redirection := self._check_cart_and_addresses(order_sudo):
            return redirection
        
        order_sudo._onchange_partner_shipping_id()
        return super().shop_confirm_order(**post)

    @http.route()
    def product(self, product, category='', search='', **kwargs):
        r = super(WebsiteSale, self).product(product, category, search, **kwargs)
        wk_auction = product.sudo()._get_nondraft_auction()
        if wk_auction and not(wk_auction.product_sale):
            wk_auction.sudo().set_auction_state()
            r.qcontext.update(wk_auction.get_publish_fields())
        return r

    @http.route(
        ['/auction/place/bid'],
        type='http', auth="public", website=True,csrf=False)
    def auction_place_bid(self,**post):
        auction_obj=request.env['wk.website.auction'].sudo().browse(int(post.get('auction_fk')))
        post['bid_offer'] = round(request.website.pricelist_id.currency_id._convert(float(post.get('bid_offer')),auction_obj.currency_id,request.env.company,datetime.datetime.now()))
        referrer  =request.httprequest.referrer and request.httprequest.referrer or '/shop/product/%s'%(auction_obj.product_tmpl_id.id)
        website_partner=request.website._get_website_partner()
        if not website_partner:
            return werkzeug.utils.redirect(referrer+ "#loginfirst")
        if auction_obj.state not in ['running', 'extend']:
            return werkzeug.utils.redirect(referrer+ "#bid_notallow")
        try:
            res = auction_obj.create_bid(post.get('bid_type'),float(post.get('bid_offer')),website_partner.id)
            return werkzeug.utils.redirect(referrer + "#bidsubmit" )
        except MinimumBidException as e:
            return werkzeug.utils.redirect(referrer + "#minbid" )
        except AutoBidException as e:
            return werkzeug.utils.redirect(referrer + "#autobid" )
        except Exception as e:
            _logger.info("Auction Error %r",e)
            return werkzeug.utils.redirect(referrer + "#biderr" )
        return werkzeug.utils.redirect(referrer)

    @http.route(
        ['/auction/buy/now/<model("wk.website.auction"):auction_obj>'],
        type='http', auth="public", website=True)
    def auction_buy_now(self,auction_obj,**post):
        order = request.website.sale_get_order(force_create=1)
        # res = request.env['website.virtual.product'].sudo().add_virtual_product(
        #     order_id=order.id,
        #     product_id=auction_obj.product_id,
        #     product_price=auction_obj.buynow_price,
        #     virtual_source='wk_website_auction',
        # )
        price_unit = auction_obj.product_id.currency_id._convert(auction_obj.buynow_price,request.website.pricelist_id.currency_id,request.env.company,fields.datetime.now())
        values = {
            'price_unit':price_unit,
            'virtual_source':'wk_website_auction',
            'is_virtual':True,
            'auction_product_direct_buy':True
            }
        response = order._cart_update(product_id=auction_obj.product_id.id, line_id=None, add_qty=1, set_qty=1, **post)
        sale_line_id = request.env['sale.order.line'].sudo().browse(response.get('line_id'))
        sale_line_id.write(values)
        return werkzeug.utils.redirect('/shop/cart' + "#create" )


    @http.route(
        ['/auction/cart/create/<model("wk.website.auction"):auction_obj>',
        '/auction/cart/update/<model("wk.website.auction"):auction_obj>'],
        type='http', auth="public", website=True)
    def auction_cart_create(self,auction_obj,**post):
        auction_obj = auction_obj.sudo()
        referrer  =request.httprequest.referrer and request.httprequest.referrer or '/shop/product/%s'%(auction_obj.product_tmpl_id.id)
        if auction_obj.state=='complete':
            order = request.website.sale_get_order(force_create=1)
            product_price = auction_obj.currency_id._convert(float(auction_obj.current_price),request.website.pricelist_id.currency_id,request.env.company,datetime.datetime.now())
            res = request.env['website.virtual.product'].sudo().add_virtual_product(
                order_id=order.id,
                product_id=auction_obj.product_id,
                product_price=product_price,
                virtual_source='wk_website_auction',
            )
            if res:
                res.virtual_product_price = auction_obj.current_price
                auction_obj.order_id=order.id
                auction_obj.action_finish_auction()
        return request.redirect('shop/cart')

    @http.route(
        ['''/auction/unsubscribe/<model("wk.website.auction"):auction_obj>/<string:deactivate_token>'''],
        type='http', auth="public", website=True,csrf=False)
    def auction_unsubscribe(self,auction_obj,deactivate_token=None,**post):
        referrer  =request.httprequest.referrer and request.httprequest.referrer or '/shop/product/%s'%(auction_obj.product_tmpl_id.id)
        partner = request.website._get_website_partner()
        if not partner:
            return werkzeug.utils.redirect(referrer+ "#loginfirst")
        subscriber_obj =  request.env['wk.auction.subscriber']
        template_unsubscribe =request.env.ref('website_auction.notify_subscriber_unsubscribe', False)
        try:
            subscriber= auction_obj.sudo().get_active_subscriber().filtered(lambda subscriber: subscriber.deactivate_token==deactivate_token)
            if subscriber:
                subscriber.sudo().write({'subscribe':False})
                template_unsubscribe.sudo().send_mail(subscriber.id, force_send=True)
            return werkzeug.utils.redirect(referrer+ "#unsubscribed")
        except Exception as e:
            return werkzeug.utils.redirect(referrer + "#biderr" )


        return werkzeug.utils.redirect(referrer)




    @http.route(
        ['''/auction/subscribe/<model("wk.website.auction","[('state','!=','close')]"):auction_obj>'''],
        type='http', auth="public", website=True)
    def auction_subscribe(self,auction_obj,deactivate_token=None,**post):
        referrer  =request.httprequest.referrer and request.httprequest.referrer or '/shop/product/%s'%(auction_obj.product_tmpl_id.id)
        partner = request.website._get_website_partner()
        if not partner:
            return werkzeug.utils.redirect(referrer+ "#loginfirst")
        subscriber_obj =  request.env['wk.auction.subscriber']
        template_subscribe =request.env.ref('website_auction.notify_subscriber_subscribe', False)
        try:
            if partner not in auction_obj.subscriber_ids.mapped('partner_id'):
                subscriber=subscriber_obj.sudo().create(
                            {'partner_id':partner.id,
                            'wk_auction_fk':auction_obj.id,
                            })
                if subscriber:template_subscribe.sudo().send_mail(subscriber.id, force_send=True)

                return werkzeug.utils.redirect(referrer+ "#subscribe")

            elif partner in auction_obj.subscriber_ids.filtered(lambda s: not s.subscribe).mapped('partner_id'):
                subscriber=subscriber_obj.sudo().search(
                            [('partner_id','=',partner.id),
                            ('wk_auction_fk','=',auction_obj.id)],order='create_date desc')
                
                if subscriber:
                    subscriber.sudo().write({'subscribe':True})
                    template_subscribe.sudo().send_mail(subscriber.id, force_send=True)
                return werkzeug.utils.redirect(referrer+ "#subscribe")
        except Exception as e:
            return werkzeug.utils.redirect(referrer + "#biderr" )


        return werkzeug.utils.redirect(referrer)


    @http.route(
        ['/product/auction/<model("wk.website.auction"):auction_obj>',
         '/product/auction/<model("wk.website.auction"):auction_obj>/page/<int:page>'
        ],
        type='http', auth="public", website=True,csrf=False)
    def auction_product_bids(self,auction_obj,page=1,**post):
        values={}
        values.update(auction_obj.sudo().get_publish_fields())
        bid_record=[]
        Bidder = request.env['wk.auction.bidder'].sudo()
        domain = [('bid_type','!=','auto'),('auction_fk', '=', auction_obj.id)]
        bid_count = Bidder.search_count(domain)
        pager = request.website.pager(
            url='/product/auction/%s'%(auction_obj.id),
            total=bid_count,
            page=page,
            step=5
        )
        bidders = Bidder.search(domain, limit=5, offset=pager['offset'],order='id desc')
        values['bidders'] = bidders
        values['pager'] = pager
        return request.render("website_auction.product_auction",values )


class website_virtual_productInherit(website_virtual_product):
    def wk_website_auction_product_remove(self,temp):
        print(f"\n\n\n\n wk_website_auction_product_remove _init \n\n\n\n")
        sale_order_line=request.env['sale.order.line'].sudo().search(
            [('id', '=', temp),('virtual_source','=','wk_website_auction')]
        )
        if sale_order_line:
            auction_ids=request.env['wk.website.auction'].search([
                ('winner_id','=',request.website._get_website_partner().id),
                ('order_id','=',sale_order_line.order_id.id),
                ('state','in',['complete','finish']),
            ])
            if auction_ids:
                for auction_obj in auction_ids:
                    auction_obj.order_id=None
                    auction_obj.action_complete_auction()#='complete'
        return sale_order_line.unlink()
