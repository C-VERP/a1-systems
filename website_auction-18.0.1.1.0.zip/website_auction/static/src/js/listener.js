/** @odoo-module **/

import { Component, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { browser } from "@web/core/browser/browser";
import { session } from '@web/session';
import { throttleForAnimation } from "@web/core/utils/timing";
import { rpc } from "@web/core/network/rpc";
import { _t } from "@web/core/l10n/translation";
import { localization } from "@web/core/l10n/localization";
import { insertThousandsSep } from "@web/core/utils/numbers";

const UPDATE_BUS_PRESENCE_DELAY = 60000;
var globalSelf;


export const WebsiteAuctionListener = {
    dependencies: ["bus_service", "notification"],
    start(env, { bus_service, notification }) {
        var self = this
        this.added_channel_list = [];
        this.bus_service = env.services["bus_service"];
        self.startpolling();
    },


    /**
     * Initiates polling for updating bus presence and handling WebSocket notifications.
     *
     * @throws {Error} If there is an issue starting the polling or handling WebSocket notifications.
     *
    */
    startpolling() {
        try{
            var self = this;
            const imStatusModelToIds = {};
            let updateBusPresenceTimeout;
            const LOCAL_STORAGE_PREFIX = "presence";
            let lastPresenceTime =
                browser.localStorage.getItem(
                    `${LOCAL_STORAGE_PREFIX}.lastPresence`
                ) || new Date().getTime();
            const throttledUpdateBusPresence = throttleForAnimation(
                function updateBusPresence() {
                    clearTimeout(updateBusPresenceTimeout);
                    const now = new Date().getTime();
                    self.bus_service.send("update_presence", {
                        inactivity_period: now - lastPresenceTime,
                        im_status_ids_by_model: { ...imStatusModelToIds },
                    });
                    updateBusPresenceTimeout = browser.setTimeout(
                        throttledUpdateBusPresence,
                        UPDATE_BUS_PRESENCE_DELAY
                    );
                },
                UPDATE_BUS_PRESENCE_DELAY
            );
            browser.setTimeout(throttledUpdateBusPresence, 250);
            self.bus_service.addEventListener("notification", self._onNotification);
            self.add_channel(self.get_formatted_channel_name());
            self.bus_service.addEventListener(
                "reconnect",
                throttledUpdateBusPresence
            );
            globalSelf = self;
            console.log("[STARTED] WebSocket...");
        }
        catch(error){
            console.log(`Failed to start polling: ${error.message}`);
        }
    },


    /**
     * Generates a formatted channel name based on the session database.
     *
     * @param {string} channel - The original channel name.
     * @returns {string} The formatted channel name.
     * 
    */
    get_formatted_channel_name(channel) {
        try{
            var self = this;
            return (
                session.db + "_website_auction"
            );
        }
        catch(error){
            console.log(`Failed to generate formatted channel name: ${error.message}`);
        }
    },


    /**
     * Add a channel to the bus service and keeps track of added channels.
     *
     * @param {string} channel - The name of the channel to be added.
     *
     * @throws {Error} If there is an issue adding the channel to the bus service.
     *
     */
    add_channel(channel) {
        try{
            var self = this;
            // self.bus_service._isMasterTab = true;
            if (self.added_channel_list.indexOf(channel) === -1) {
                self.bus_service.addChannel(channel);
                self.added_channel_list.push(channel);
            }
        }
        catch(error){
            console.log(`Failed to add channel: ${error.message}`);
        }
    },


    /**
     * Handles WebSocket notifications and processes the payload using the _modify_data function.
     *
     * @param {Object} notifications - Object containing WebSocket notifications.
     *
     * @throws {Error} If there is an issue processing the notifications or modifying the data.
     *
     */
    _onNotification(notifications) {
        try{
            var self = this;
            $.each(notifications.detail, function (index, notification) {
                $.each(notification.payload, function (index, payload) {
                    globalSelf._modify_data(payload);
                });
            })
            console.log("[RECEIVED] WebSocket response...");
        }
        catch(error){
            console.log(`Failed to handle WebSocket notifications: ${error.message}`);
        }
    },


    /**
     * Asynchronously modifies data based on the provided payload and updates the UI.
     *
     * @param {Object} payload - Object containing data for modifying the bid.
     *
     * @throws {Error} If there is an issue with the JSON-RPC request or processing the response.
     * 
     */
    async _modify_data(payload) {
        try{
            var self = this;
            var price_by_id = {};
            price_by_id[payload.record_id] = payload.amount;
            var current_record_id = +($('.span_current_bid_amount').attr('rec_id'))
            var current_pricelist = +($('.span_current_bid_amount').attr('pricelist'))
            var current_currency_id = +($('.span_current_bid_amount').attr('currency_id'))
            var partner_id = +($('.bid-type').attr('partner_id'))
            var total_bids = payload.total_bids
            var auction_id = +($('.bid-type').data('auction_id'))
            if (payload.record_id == current_record_id) {
                var final_price = 0
    
                if (payload.currency_id == current_currency_id) {
                    final_price = parseFloat(payload.amount)
                }
                else {
                    final_price = await self.priceformat(payload, current_pricelist)
                }
                var precision = 2;
                if ($('.decimal_precision').length) {
                    precision = parseInt($('.decimal_precision').last().data('precision'));
                }
                var formatted = final_price.toFixed(precision).split(".");
                const { thousandsSep, decimalPoint, grouping } = localization;
                formatted[0] = insertThousandsSep(formatted[0], thousandsSep, grouping);
                $('.current_amount .oe_currency_value').empty()
                $('.current_amount .oe_currency_value').append(formatted.join(decimalPoint))
    
                await rpc('/web/dataset/call_kw/wk.website.auction/login_user_is_auto_bidder_socket', {
                    model: 'wk.website.auction',
                    method: 'login_user_is_auto_bidder_socket',
                    args: [{}],
                    kwargs: {
                        'partner_id': partner_id,
                    },
                }).then(function (res) {
                    if (res) {
                        $('input[name="bid_type"][value="simple"]').parent().remove()
                    }
                    else {
                        if ($('input[name="bid_type"][value="simple"]')) {
                            $('input[name="bid_type"][value="simple"]').parent().remove()
                        }
                        $('.bid-type').prepend(`
                            <label class="radio-inline">
                            <input type="radio" name="bid_type" class="me-2" value="simple" data-oe-model="ir.ui.view" data-oe-id="2107" data-oe-field="arch" data-oe-xpath="/t[1]/t[1]/div[1]/form[1]/div[1]/label[1]/input[1]">Simple Bid
                          </label>
                            `)
                    }
                })
                var get_next_bid_target = $('.span_next_bid_amount .oe_currency_value')
                await self.get_next_bid(get_next_bid_target, payload, auction_id, current_pricelist)
                var bids_target = $('.product_page_bids .span_total_bids')
                await self.get_total_bids(bids_target, auction_id)
    
            }
            if(window.location.pathname == '/products-on-auction'){
                self._modify_data_product_page(payload)
            }
        }
        catch(error){
            console.log(`Failed to modify data: ${error.message}`);
        }
    },


    /**
     * Asynchronously modifies data on the product page based on the provided payload.
     *
     * @param {Object} payload - Object containing data for modifying the bid on the product page.
     *
     * @throws {Error} If there is an issue modifying the data or updating the product page UI.
     *
     */
    async _modify_data_product_page(payload){
        try{
            var final_price = 0
            var self = this
            var auction_page_bidstarget = $(`#auction_id${payload.record_id}`).find('.span_total_bids')
            self.get_total_bids(auction_page_bidstarget, payload.record_id, true)
            var product_page_currency_id = +($(`#product_auction_id${payload.record_id}`).attr('currency_id'))
            if (payload.currency_id == product_page_currency_id) {
                final_price = parseFloat(payload.amount)
            }
            else {
                final_price = await self.priceformat(payload, product_page_currency_id)
            }
            var precision = 2;
            if ($('.decimal_precision').length) {
                precision = parseInt($('.decimal_precision').last().data('precision'));
            }
            var formatted = final_price.toFixed(precision).split(".");
            const { thousandsSep, decimalPoint, grouping } = localization;
            formatted[0] = insertThousandsSep(formatted[0], thousandsSep, grouping);
            $(`#product_auction_id${payload.record_id}`).find('.oe_currency_value').empty()
            $(`#product_auction_id${payload.record_id}`).find('.oe_currency_value').append(formatted.join(decimalPoint))
        }
        catch(error){
            console.log(`Failed to modify data on product page: ${error.message}`)
        }
    },


    /**
     * Asynchronously fetches the total number of bids and updates the UI.
     *
     * @param {JQuery} target - jQuery object representing the HTML element where the total bids will be displayed.
     * @param {number} auction_id - The unique identifier of the auction.
     * @param {boolean} [auction_page=false] - Optional parameter to determine the display format on the auction page.
     *
     * @throws {Error} If there is an issue with the JSON-RPC request or processing the response.
     *
    */
    async get_total_bids(target, auction_id, auction_page = false) {
        try{
            await rpc('/web/dataset/call_kw/wk.website.auction/get_total_bids_socket', {
                model: 'wk.website.auction',
                method: 'get_total_bids_socket',
                args: [{}],
                kwargs: {
                    'auction_id': auction_id
                },
            }).then(function (total_bids) {
                target.empty()
                if (auction_page) {
                    target.append(`${total_bids} Bids`)
                }
                else {
                    target.append(`[ ${total_bids} Bids ]`)
                }
    
            })
        }
        catch(error){
            console.log(`Failed to update total bids: ${error.message}`);
        }
    },


    /**
     * Asynchronously fetches the next bid amount from the server and updates the UI.
     *
     * @param {JQuery} target - jQuery object representing the HTML element where the bid amount will be displayed.
     * @param {Object} payload - Object containing additional data for the bid.
     * @param {number} auction_id - The unique identifier of the auction.
     * @param {number} current_pricelist - The current pricelist for formatting the bid amount.
     *
     * @throws {Error} If there is an issue with the JSON-RPC request or processing the response.
     *
     */
    async get_next_bid(target, payload, auction_id, current_pricelist) {
        var self = this
        try {
            await rpc('/web/dataset/call_kw/website/get_next_bid_socket', {
                model: 'website',
                method: 'get_next_bid_socket',
                args: [{}],
                kwargs: {
                    'auction_id': auction_id,
                },
            }).then(async function (res) {
                payload.amount = res
                var price = await self.priceformat(payload, current_pricelist)
                if (price) {
                    var price_data = parseFloat(price)
                    var precision = 2;
                    var formatted = price_data.toFixed(precision).split(".");
                    const { thousandsSep, decimalPoint, grouping } = localization;
                    if (+(formatted[1]) === 0) {
                        precision = 1
                        formatted = price_data.toFixed(precision).split(".");
                    }
                    var final_price = formatted.join(decimalPoint)
                    $('.auction_amount').find('input').attr({
                        'value': final_price,
                        'min': final_price
                    })
                    var precision = 2;
                    var formatted = price_data.toFixed(precision).split(".");
                    formatted[0] = insertThousandsSep(formatted[0], thousandsSep, grouping);
                    var final_price_thousandsSep = formatted.join(decimalPoint)
                    target.empty()
                    target.append(final_price_thousandsSep)
                }

            })
        }
        catch (error) {
            console.log(`Failed to update bid: ${error.message}`);
        }
    },


    /**
     * Asynchronously formats the price using the provided payload and current pricelist.
     *
     * @param {Object} payload - Object containing additional data for the bid.
     * @param {number} current_pricelist - The current pricelist for formatting the bid amount.
     * @returns {Promise<number>} A promise that resolves to the formatted price as a number.
     *
     * @throws {Error} If there is an issue with the JSON-RPC request or processing the response.
     * 
     */
    async priceformat(payload, current_pricelist) {
        var final_price = 0
        try{
            await rpc('/web/dataset/call_kw/wk.website.auction/priceformat', {
                model: 'wk.website.auction',
                method: 'priceformat',
                args: [{}],
                kwargs: {
                    'payload': payload,
                    'current_pricelist': current_pricelist,
                },
            }).then(function (price) {
                final_price = parseFloat(price)
            })
            return final_price
        }
        catch(error){
            console.log(`Failed to format the price: ${error.message}`)
        }
    },



}

registry.category("services").add("WebsiteAuctionListener", WebsiteAuctionListener);
