"""
Used For Add Line Tax amount field in Account Move Line
"""
from collections import defaultdict
from odoo import models, fields, api, _
from odoo.tools import frozendict
from odoo.tools import (formatLang)


class AccountMove(models.Model):
    """
    Use: Calculate Tax amount in Journal Items
    """
    _inherit = 'account.move'

    @api.depends_context('lang')
    @api.depends(
        'invoice_line_ids.currency_rate',
        'invoice_line_ids.tax_base_amount',
        'invoice_line_ids.tax_line_id',
        'invoice_line_ids.price_total',
        'invoice_line_ids.price_subtotal',
        'invoice_payment_term_id',
        'partner_id',
        'currency_id',
        'invoice_line_ids.line_tax_amount_percent'
    )
    def _compute_tax_totals(self):
        """
        Override this method for pass context tax_computation_context to calculate percent of
        tax amount for invoice lines.
        :return:
        """
        for move in self:
            if move.is_invoice(include_receipts=True):
                base_lines, tax_lines = move._get_rounded_base_and_tax_lines()
                move.tax_totals = self.env['account.tax']._get_tax_totals_summary(
                    base_lines=base_lines,
                    currency=move.currency_id,
                    company=move.company_id,
                    cash_rounding=move.invoice_cash_rounding_id,
                )
                move.tax_totals['display_in_company_currency'] = (
                        move.company_id.display_invoice_tax_company_currency
                        and move.company_currency_id != move.currency_id
                        and move.tax_totals['has_tax_groups']
                        and move.is_sale_document(include_receipts=True)
                )
            else:
                # Non-invoice moves don't support that field (because of multicurrency: all lines of the invoice share the same currency)
                move.tax_totals = None


class AccountMoveLine(models.Model):
    """
    Use: Add Line tax amount in Account Move Line
    """
    _inherit = 'account.move.line'


    line_tax_amount_percent = fields.Float(digits='Line Tax Amount', string="Tax amount in per(%)")

    @api.depends('quantity', 'discount', 'price_unit', 'tax_ids', 'currency_id', 'line_tax_amount_percent')
    def _compute_totals(self):
        """
        Override this method for update context tax_computation_context for calculate
        tax percentage for invoice lines.
        :return:
        """
        AccountTax = self.env['account.tax']
        for line in self:
            if line.display_type not in ('product', 'cogs'):
                line.price_total = line.price_subtotal = False
                continue

            base_line = line.move_id._prepare_product_base_line_for_taxes_computation(line)
            AccountTax._add_tax_details_in_base_line(base_line, line.company_id)
            line.price_subtotal = base_line['tax_details']['raw_total_excluded_currency']
            line.price_total = base_line['tax_details']['raw_total_included_currency']
