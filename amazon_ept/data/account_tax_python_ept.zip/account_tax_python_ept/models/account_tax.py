# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api, _
from odoo.tools.safe_eval import safe_eval
from odoo.exceptions import ValidationError

FORMULA_ALLOWED_TOKENS = {
    '(', ')',
    '+', '-', '*', '/', ',', '<', '>', '<=', '>=',
    'and', 'or', 'None',
    'base', 'quantity', 'price_unit',
    'min', 'max','line_tax_amount_percent',
}

class AccountTax(models.Model):
    """
    Use: Override Field and Methods for Compute Tax
    """
    _inherit = 'account.tax'

    formula = fields.Text(
        help="Compute the amount of the tax by setting the variable "
             "'result'.\n\n"
             ":param base_amount: float, actual amount on which the "
             "tax is applied\n"
             ":param price_unit: float\n"
             ":param line_tax_amount_percent: float\n"
             ":param quantity: float\n"
             ":param company: res.company recordset singleton\n"
             ":param product: product.product recordset singleton"
             " or None\n"
             ":param partner: res.partner recordset singleton or None")

    is_amazon_tax_ept = fields.Boolean(string='Is Amazon Tax enable', default=False)

    def _compute_amount(self, base_amount, price_unit, quantity=1.0, product=None, partner=None,
                        fixed_multiplicator=1):
        """
        Override this method for update line tax amount percent for calculate tax value
        as per python cede.
        :param: base_amount: float
        :param: price_unit: float
        :param: quantity: float
        :param: product: product.product()
        :param: partner: res.partner()
        :param: fixed_multiplicator: float
        :return: dict {}
        """
        self.ensure_one()
        if self.amount_type != 'code':
            return super(AccountTax, self)._compute_amount(base_amount,
                                                           price_unit, quantity,
                                                           product, partner, fixed_multiplicator)
        if product and product._name == 'product.template':
            product = product.product_variant_id
        company = self.env.company
        localdict = self._context.get('tax_computation_context', {'line_tax_amount_percent': 0.00})
        localdict.update({'base_amount': base_amount, 'price_unit': price_unit,
                          'quantity': quantity, 'product': product, 'partner': partner,
                          'company': company})
        safe_eval(self.formula, localdict, mode="exec", nocopy=True)
        return localdict['result']

    @api.model
    def _create_amazon_python_tax(self):
        """
        Create Tax configuration for calculate tax based on calculation.
        :return:  boolean
        """
        amz_tax_id = self.search(
            [('formula', '=', 'price_unit * quantity * (line_tax_amount_percent / 100)')])
        country = self.env.ref('base.us', raise_if_not_found=False)
        if not amz_tax_id and country:
            tax_vals = {
                'name': 'Amazon Tax',
                'amount_type': 'code',
                'type_tax_use': 'sale',
                'country_id': country.id,
                'amount': 0.00,
                'price_include': False,
                'formula': 'price_unit * quantity * (line_tax_amount_percent / 100)',
                'is_amazon_tax_ept':True
            }
            amz_tax_id = self.create(tax_vals)
            amz_tax_id.onchange_price_include()
        return True

    def _check_formula(self):
        """ Check the formula is passing the minimum check to ensure the compatibility between both evaluation
        in python & javascript.
        """
        self.ensure_one()

        def get_number_size(formula, i):
            starting_i = i
            seen_separator = False
            while i < len(formula):
                if formula[i].isnumeric():
                    i += 1
                elif formula[i] == '.' and (i - starting_i) > 0 and not seen_separator:
                    i += 1
                    seen_separator = True
                else:
                    break
            return i - starting_i

        formula_decoded_info = self.formula_decoded_info
        allowed_tokens = FORMULA_ALLOWED_TOKENS.union(
            f"product['{field_name}']" for field_name in formula_decoded_info['product_fields'])
        formula = formula_decoded_info['py_formula']

        i = 0
        while i < len(formula):

            if formula[i] == ' ':
                i += 1
                continue

            continue_needed = False
            for token in allowed_tokens:
                if formula[i:i + len(token)] == token:
                    i += len(token)
                    continue_needed = True
                    break
            if continue_needed:
                continue

            number_size = get_number_size(formula, i)
            if number_size > 0:
                i += number_size
                continue

            raise ValidationError(_("Malformed formula '%(formula)s' at position %(position)s", formula=formula, position=i))

    @api.model
    def _eval_tax_amount_formula(self, raw_base, evaluation_context):
        """ Override this method to add the line_tax_amount_percent filed to calculate the formula.
        :return:                    The tax base amount.
        """
        if self.is_amazon_tax_ept:
            self._check_formula()
            # Safe eval.
            formula_context = {
                'price_unit': evaluation_context['price_unit'],
                'quantity': evaluation_context['quantity'],
                'product': evaluation_context['product'],
                'base': raw_base,
                'min': min,
                'max': max,
                'line_tax_amount_percent': self.env.context.get('tax_computation_context') and self.env.context.get(
                    'tax_computation_context').get('line_tax_amount_percent') or 0
            }
            try:
                return safe_eval(
                    self.formula_decoded_info['py_formula'],
                    globals_dict=formula_context,
                    locals_dict={},
                    locals_builtins=False,
                    nocopy=True,
                )
            except ZeroDivisionError:
                return 0.0
        else:
            res = super(AccountTax, self)._eval_tax_amount_formula(raw_base, evaluation_context)
            return res

    @api.model
    def _add_tax_details_in_base_line(self, base_line, company, rounding_method=None):
        """
            Override this method to add the line_tax_amount_percent for updating the
            tax based on formula.
        """
        line = base_line.get('record')
        context = {}
        if line and line._fields.get('line_tax_amount_percent') and line.line_tax_amount_percent > 0:
            context.update({
                'line_tax_amount_percent': line.line_tax_amount_percent or 0.0})
            price_unit_after_discount = base_line['price_unit'] * (1 - (base_line['discount'] / 100.0))
            taxes_computation = base_line['tax_ids'].with_context(tax_computation_context=context)._get_tax_details(
                price_unit=price_unit_after_discount,
                quantity=base_line['quantity'],
                precision_rounding=base_line['currency_id'].rounding,
                rounding_method=rounding_method or company.tax_calculation_rounding_method,
                product=base_line['product_id'],
                special_mode=base_line['special_mode'],
            )
            rate = base_line['rate']
            tax_details = base_line['tax_details'] = {
                'raw_total_excluded_currency': taxes_computation['total_excluded'],
                'raw_total_excluded': taxes_computation['total_excluded'] / rate if rate else 0.0,
                'raw_total_included_currency': taxes_computation['total_included'],
                'raw_total_included': taxes_computation['total_included'] / rate if rate else 0.0,
                'taxes_data': [],
            }
            if company.tax_calculation_rounding_method == 'round_per_line':
                tax_details['raw_total_excluded'] = company.currency_id.round(tax_details['raw_total_excluded'])
                tax_details['raw_total_included'] = company.currency_id.round(tax_details['raw_total_included'])
            for tax_data in taxes_computation['taxes_data']:
                tax_amount = tax_data['tax_amount'] / rate if rate else 0.0
                base_amount = tax_data['base_amount'] / rate if rate else 0.0
                if company.tax_calculation_rounding_method == 'round_per_line':
                    tax_amount = company.currency_id.round(tax_amount)
                    base_amount = company.currency_id.round(base_amount)
                tax_details['taxes_data'].append({
                    **tax_data,
                    'raw_tax_amount_currency': tax_data['tax_amount'],
                    'raw_tax_amount': tax_amount,
                    'raw_base_amount_currency': tax_data['base_amount'],
                    'raw_base_amount': base_amount,
                })
        else:
            return super(AccountTax,self)._add_tax_details_in_base_line(base_line, company, rounding_method=rounding_method)


