from . import sale_order_line
from . import account_tax
from . import account_move_line
from . import sale_order

FORMULA_ALLOWED_TOKENS = {
    '(', ')',
    '+', '-', '*', '/', ',', '<', '>', '<=', '>=',
    'and', 'or', 'None',
    'base', 'quantity', 'price_unit',
    'min', 'max', 'line_tax_amount_percent'
}
